(function (angular) {
	'use strict';

	var module = angular.module('moviecat.coming_soon', ['ngRoute']);

	module.config(['$routeProvider', function ($routeProvider) {
		$routeProvider.when('/coming_soon/1', {
			templateUrl: 'coming_soon/view.html',
			controller: 'ComingSoonController'
		});
	}])

	module.controller('ComingSoonController', ['$scope',function ($scope) {
		$scope.title = "即将上映的电影";
	}]);
})(angular);
